import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.lectra.nursing',
  appName: 'LECTRA',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
