package com.lectra.nursing;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
