/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * LECTRA API & Backend Connectivity Configuration
 */

export const DEFAULT_BACKEND_URL =
  import.meta.env.VITE_BACKEND_URL ||
  'https://ais-dev-jl5x6zotbgcdvo65posb5w-606512771037.europe-west3.run.app';

export function getBackendBaseUrl(): string {
  const savedUrl = localStorage.getItem('lectra_backend_url');
  if (savedUrl && savedUrl.trim()) {
    return savedUrl.trim().replace(/\/+$/, '');
  }

  // Detect if running inside native Android Capacitor WebView
  const isCapacitor =
    window.location.protocol === 'capacitor:' ||
    (window.location.hostname === 'localhost' && !window.location.port) ||
    Boolean((window as any).Capacitor?.isNativePlatform?.());

  if (isCapacitor) {
    return DEFAULT_BACKEND_URL;
  }

  // Running in standard web browser / dev server
  return '';
}

export function setBackendBaseUrl(url: string): void {
  localStorage.setItem('lectra_backend_url', url.trim());
}

export function apiUrl(endpoint: string): string {
  const base = getBackendBaseUrl();
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return `${base}${cleanEndpoint}`;
}
